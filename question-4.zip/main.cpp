class Solution {
public:
    int maxSubArray(vector<int>& nums) {
         long long sum=INT_MIN;
        long long c=0;
        for(int i=0;i<nums.size();i++)
        {
            c+=nums[i];
            sum=max(c,sum);
            if(c<0)
            {
                c=0;
            }
            
        }
        
        return sum;
    }
};